// gihub_Ocher.cpp : Defines the entry point for the console application.
//
/*! \file gihub_Ocher.cpp
\brief A Documented file.

Details.
*/

#include "stdafx.h"

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

int main()
{
	int *a, N, n;
	bool *b;

	cout << "scolko kletok? \n"; /// vvodim kol-vo kletok 
	cin >> n;
	a = new int[n];
	b = new bool[n];
	for (int i = 0; i<n; i++)
		b[i] = 0;

	cout << "scolko deistvie? \n";/// vvodim kol-vo deistvii
	cin >> N;

	for (int k = 0; k<N; k++)
	{
		int x, i;
		cout << k + 1;

		fflush(stdin);
		switch (_getche())
		{
		case 'a': /// dobavlyaem znach

			cin >> x;
			for (i = n - 1; i >= 0; i--)
			{
				if (i)
				{
					if (b[i - 1] && !b[i])
					{
						b[i] = 1;
						a[i] = x;
						cout << "sdelano"; 
						break;
					};
				}
				else
				{
					if (!b[i])
					{
						b[i] = 1;
						a[i] = x;
						cout << "sdelano";
						break;
					}
					else
					{
						cout << "ochered polna \n";
						k--;
					};
				}
			}
			break;

		case 'd': /// udaliaem znach
			for (i = 0; i<n; i++)
				if (b[i]) break;

			if (i == n)
			{
				cout << "ochered pusta \n";
				k--;
			}
			else
			{
				cout << "\n";
				b[i] = 0;
			}
			break;

		default:
			cout << "newernaya komanda \n";
			k--;
		} //switch
	} //for

	cout << "ochered: \n"; /// vivodim massiv
	for (int k = 0; k<n; k++)
	{
		cout << k+1 << " ";
		if (b[k]) cout << a[k];
		else      cout << "pusto ";
	}

	delete a, b;
	_getch();
}


