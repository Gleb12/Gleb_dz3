// github_massive.cpp : Defines the entry point for the console application.
//
/*! \file github_massive.cpp
\brief A Documented file.

Details.
*/

#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

using namespace std;

int main()
{
	int *a, N, n;
	bool *b;

	cout << "scolko yacheek? \n";///vvodim kol-vo yacheek
	cin >> n;
	a = new int[n];
	b = new bool[n];
	for (int i = 0; i<n; i++)
		b[i] = 0;

	cout << "scolko deistv? \n";///vvodim kol-vo deistvii
	cin >> N;

	for (int k = 0; k<N; k++)
	{
		int x, i;
		cout << k + 1;

		fflush(stdin);
		switch (_getche())
		{
		case 'a':///dobavliaem stroky v yacheiku
			cin >> x;

			for (i = n - 1; i >= 0; i--)
				if (i)
				{
					if (!b[i] && b[i - 1]) break;
				}
				else
				{
					if (!b[i]) break;
					else {
						cout << "ochered polna \n";
						k--;
					}
				}

			b[i] = 1;
			a[i] = x;
			break;

		case 'd':///udaliaem stroku s konca
			for (i = 0; i<n; i++)
				if (b[i]) break;

			if (i == n)
			{
				cout << "ochered pusta \n";
				k--;
			}
			else
			{
				printf("\n");
				b[i] = 0;
			}
			break;

		default:
			cout << "newernaya komanda \n";
			k--;
		} 
	} 
	cout << "ochered ";
	for (int k = 0; k<n; k++)///vivodim resultat
	{
		cout << k+1;
		if (b[k]) cout << a[k] << " ";
		else      cout << "pusta ";
	}

	delete a;
	delete b;
	_getch();
}

