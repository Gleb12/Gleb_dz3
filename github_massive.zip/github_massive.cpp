// github_massive.cpp : Defines the entry point for the console application.
//
/*! \file github_massive.cpp
\brief A Documented file.

Details.
*/

#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

using namespace std;

struct list
{
	int num;
	list* next;
};

list* pos(list *first, int n)
{
	for (int i = 0; i<n; i++)
	{
		if (!(first->next))
			first->next = new list;
		first = first->next;
	}
	return first;
}

int main()
{
	int N, n = 0;
	list *head, *count;

	cout << " scolko deistvii"; /// vvedem kol-vo deistv
	cin >> N; 

	for (int k = 0; k<N; k++)
	{
		cout << n << "\n"; 
		char act[2];
		int x, i;
		cout << k + 1; 
		fflush(stdin);
		cout << " vvedite deistvie";
		cin >> act;  /// vvodim deistvie
		cout << " scolko yacheek";  cin >> i;

		if (!strcmp(act, "a"))
		{
			cin >> x; 
			if (!n) head = new list;

			if (i >= n)
			{
				cout << "dobav novie yacheiki \n" << i - n + 1;
				n = i + 1;
			}
			else cout << "sdelano \n"; 

			count = pos(head, i);
			count->num = x;
		}
		else 
			if (!strcmp(act, "d") && i<n) /// udaliaem yacheiku
			{
				list *buf;
				buf = pos(head, i);

				if (i)
					if (i == n - 1) pos(head, i - 1)->next = 0;
					else pos(head, i - 1)->next = buf->next;
				else head = head->next;

				delete buf;
				n--;
				cout << "sdelano \n"; 
			}
			else
			{
				cout << "nevernaya komanda \n";  
				k--;
			}
	}

	cout << "spicok: ";  /// vivodim spisok
	if (!n) cout << "pusto "; 
	for (int k = 0; n - k; k++)
	{
		cout << k << " " << head->num; 
		count = head->next;
		delete head;
		head = count;
	}
	_getch;
}

