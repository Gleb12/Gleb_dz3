// github_stec.cpp : Defines the entry point for the console application.
//
/*! \file github_stec.cpp
\brief A Documented file.

Details.
*/

#include "stdafx.h"
#include <conio.h>
#include <malloc.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

struct stec
{
	int num;
	stec * prev;///sosdaiom strukturu
};

int _tmain(int argc, _TCHAR* argv[])
{
	int kol, n = 0;
	stec *last = 0, *count = 0;///ukazateli na poslednii i obichnii
	cout << " kolvo ";
	cin >> kol;/// vvodim kol-vo operacii

	for (int i = 0; i < kol; i++)
	{
		char deistv;
		int x;
		cout << "vvedite deistvie";
		cin >> deistv;
		switch (deistv)
		{
		case 'a':///dobavlenie stroki
			cout << "vvedite znach";
			cin >> x;
			count = new stec;
			count->num = x;
			count->prev = last;
			last = count;
			n++;
			break;
		case 'd':///udalenie stroki
			if (!n)
			{
				cout << "nevernaya komanda";
				i--;
				break;
			}
			count = count->prev;
			delete last;
			last = count;
			n--;
			break;
		default:
			cout << "nevernaya komanda";
			i--;
		}
	}

	cout << "stek: ";///vivod
	if (!n) cout << "pustoi";
	while (n)
	{
		stec *buf;
		buf = count;
		printf("%d) %d\n", --n, count->num);
		count = count->prev;
		delete buf;
	}
	return 0;
}
