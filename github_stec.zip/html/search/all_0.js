var searchData=
[
  ['_5ftmain',['_tmain',['../github__stec_8cpp.html#a353674c5af92be7fb389265cde4e5e03',1,'github_stec.cpp']]]
];
