var searchData=
[
  ['github_5fstec_2ecpp',['github_stec.cpp',['../github__stec_8cpp.html',1,'']]]
];
