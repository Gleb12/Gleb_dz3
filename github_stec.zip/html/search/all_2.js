var searchData=
[
  ['stec',['stec',['../structstec.html',1,'']]]
];
